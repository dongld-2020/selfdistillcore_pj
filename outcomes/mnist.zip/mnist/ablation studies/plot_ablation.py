import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset

# --- CONFIGURATION ---
# Set publication quality settings (WoS Q1 Standard)
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'font.size': 12,
    'axes.labelsize': 14,
    'axes.titlesize': 16,
    'xtick.labelsize': 12,
    'ytick.labelsize': 12,
    'legend.fontsize': 11,
    'figure.dpi': 300,
    'lines.linewidth': 2.0
})

# --- DATA LOADING ---
# Map filenames to logical Legend Labels
files = {
    "Proposed (SelfDistillCore + GN)": "results_selfdistillcore_0.2_0.1_0.9_0.1_groupnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: w/o Knowledge Bank": "results_selfdistillcore_0.2_0.0_0.0_0.0_groupnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: No Normalization": "results_selfdistillcore_0.2_0.1_0.9_0.1_nogroupnormnorbatchnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: BatchNorm": "results_selfdistillcore_0.2_0.1_0.9_0.1_batchnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv"
}

data = {}
for label, filename in files.items():
    try:
        df = pd.read_csv(filename)
        data[label] = df
    except FileNotFoundError:
        print(f"Warning: File {filename} not found.")

# --- COLOR PALETTE ---
# High-contrast, colorblind-friendly palette
colors = {
    "Proposed (SelfDistillCore + GN)": "#D62728",  # Red (Highlight)
    "Ablation: w/o Knowledge Bank": "#1F77B4",     # Blue
    "Ablation: No Normalization": "#FF7F0E",       # Orange
    "Ablation: BatchNorm": "#2CA02C"               # Green
}

styles = {
    "Proposed (SelfDistillCore + GN)": "-",
    "Ablation: w/o Knowledge Bank": "--",
    "Ablation: No Normalization": "-.",
    "Ablation: BatchNorm": ":"
}

# --- PLOTTING FUNCTION ---
def plot_ablation_study():
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    
    # Metrics to plot
    metrics = [
        ('Accuracy', 'Test Accuracy (%)', 'lower right'),
        ('Loss', 'Test Loss', 'upper right'),
        ('F1-Score', 'F1-Score', 'lower right')
    ]

    for idx, (metric_col, metric_name, loc) in enumerate(metrics):
        ax = axes[idx]
        
        for label, df in data.items():
            # Smoothing for visual clarity (optional, window=1 represents raw data)
            # For WoS, raw data is often preferred unless very noisy. 
            # Here we plot raw data but with distinct markers/lines.
            ax.plot(df['Round'], df[metric_col], 
                    label=label, 
                    color=colors[label], 
                    linestyle=styles[label],
                    alpha=0.9)

        ax.set_xlabel('Communication Rounds', fontweight='bold')
        ax.set_ylabel(metric_name, fontweight='bold')
        ax.set_title(f'{metric_name} vs. Rounds')
        ax.grid(True, linestyle='--', alpha=0.6)

        # --- INSET ZOOM (Crucial for Ablation distinction) ---
        # Only zoom for Accuracy and Loss to show fine-grained differences
        # We exclude BatchNorm from zoom if it performed very poorly to keep scale readable
        if metric_col in ['Accuracy', 'Loss']:
            # Define zoom region (Last 20 rounds)
            last_round = 50
            zoom_start = 30
            
            # Create inset axis
            axins = inset_axes(ax, width="40%", height="30%", loc='center right' if metric_col == 'Accuracy' else 'center right')
            
            for label, df in data.items():
                # Skip BatchNorm in zoom if it has collapsed (optional heuristic)
                if label == "Ablation: BatchNorm" and df[metric_col].iloc[-1] < 50 and metric_col == 'Accuracy':
                    continue 
                    
                axins.plot(df['Round'], df[metric_col], 
                           color=colors[label], 
                           linestyle=styles[label])
            
            # Set limits for zoom (auto-adjust based on Proposed method)
            proposed_df = data["Proposed (SelfDistillCore + GN)"]
            y_center = proposed_df[metric_col].iloc[zoom_start:last_round].mean()
            y_std = proposed_df[metric_col].iloc[zoom_start:last_round].std()
            
            if metric_col == 'Accuracy':
                axins.set_xlim(zoom_start, last_round)
                axins.set_ylim(90, 100) # Specific for LeNet/MNIST high performance
            elif metric_col == 'Loss':
                axins.set_xlim(zoom_start, last_round)
                axins.set_ylim(0, 0.5)

            # Remove ticks for cleaner look in inset
            axins.set_xticklabels([]) 
            # axins.set_yticklabels([])
            
            # Draw box and connectors
            mark_inset(ax, axins, loc1=2, loc2=4, fc="none", ec="0.3")

    # Global Legend
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, -0.05), 
               ncol=4, frameon=True, shadow=True, borderpad=1)

    plt.tight_layout()
    plt.subplots_adjust(bottom=0.15) # Make room for legend
    
    # Save figure
    plt.savefig("SelfDistillCore_Ablation_Study.pdf", bbox_inches='tight', format='pdf')
    plt.show()

# Run the plot
plot_ablation_study()