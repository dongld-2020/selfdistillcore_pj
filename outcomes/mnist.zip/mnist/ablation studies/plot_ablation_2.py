import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset

# --- 1. CẤU HÌNH LẠI FONT SIZE (Phần quan trọng nhất) ---
# Tăng kích thước toàn bộ các thành phần để dễ nhìn hơn
plt.rcParams.update({   
    # Tăng font cơ bản
    'font.size': 20,          
    
    # Tăng font tiêu đề trục (VD: Test Accuracy, Rounds)
    'axes.labelsize': 20,     
    'axes.labelweight': 'bold', # In đậm tiêu đề trục cho rõ
    
    # Tăng font tiêu đề biểu đồ con (VD: Accuracy vs. Rounds)
    'axes.titlesize': 20,     
    'axes.titleweight': 'bold',
    
    # Tăng font các con số trên trục (Ticks)
    'xtick.labelsize': 20,    
    'ytick.labelsize': 20,
    
    # Tăng font chú thích (Legend)
    'legend.fontsize': 20,    
    
    # Tăng độ phân giải và độ dày nét vẽ
    'figure.dpi': 300,
    'lines.linewidth': 2.5,   # Đường vẽ dày hơn để tương xứng với chữ to
    'axes.linewidth': 1.5,    # Viền khung biểu đồ dày hơn
    'xtick.major.width': 1.5, # Vạch chia trục dày hơn
    'ytick.major.width': 1.5
})

# --- DATA LOADING (Giữ nguyên) ---
files = {
    "Proposed (SelfDistillCore + GN)": "results_selfdistillcore_0.2_0.1_0.9_0.1_groupnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: w/o EWMA": "results_selfdistillcore_0.2_0.0_0.0_0.0_groupnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: No Normalization": "results_selfdistillcore_0.2_0.1_0.9_0.1_nogroupnormnorbatchnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: BatchNorm": "results_selfdistillcore_0.2_0.1_0.9_0.1_batchnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv"
}

data = {}
for label, filename in files.items():
    try:
        df = pd.read_csv(filename)
        data[label] = df
    except FileNotFoundError:
        print(f"Warning: File {filename} not found.")

# --- COLOR PALETTE (Giữ nguyên) ---
colors = {
    "Proposed (SelfDistillCore + GN)": "#D62728",  
    "Ablation: w/o EWMA": "#1F77B4",     
    "Ablation: No Normalization": "#FF7F0E",       
    "Ablation: BatchNorm": "#2CA02C"               
}

styles = {
    "Proposed (SelfDistillCore + GN)": "-",
    "Ablation: w/o EWMA": "--",
    "Ablation: No Normalization": "-.",
    "Ablation: BatchNorm": ":"
}

# --- PLOTTING FUNCTION ---
def plot_ablation_study_large_font():
    # Tăng kích thước Figure tổng thể lên một chút để chứa font to
    fig, axes = plt.subplots(1, 3, figsize=(20, 7)) 
    
    metrics = [
        ('Accuracy', 'Test Accuracy (%)', 'lower right'),
        ('Loss', 'Test Loss', 'upper right'),
        ('F1-Score', 'F1-Score', 'lower right')
    ]

    for idx, (metric_col, metric_name, loc) in enumerate(metrics):
        ax = axes[idx]
        
        for label, df in data.items():
            ax.plot(df['Round'], df[metric_col], 
                    label=label, 
                    color=colors[label], 
                    linestyle=styles[label],
                    alpha=0.9)

        ax.set_xlabel('Communication Rounds') # Font size đã set ở rcParams
        ax.set_ylabel(metric_name)
        ax.set_title(f'{metric_name}') # Rút gọn title cho đỡ rối
        ax.grid(True, linestyle='--', alpha=0.6, linewidth=1.2)

        # --- INSET ZOOM ---
        if metric_col in ['Accuracy', 'Loss']:
            last_round = 50
            zoom_start = 30
            
            # Phóng to Inset box để số liệu bên trong dễ đọc hơn
            axins = inset_axes(ax, width="45%", height="35%", 
                               loc='center right' if metric_col == 'Accuracy' else 'center right')
            
            for label, df in data.items():
                if label == "Ablation: BatchNorm" and df[metric_col].iloc[-1] < 50 and metric_col == 'Accuracy':
                    continue 
                    
                axins.plot(df['Round'], df[metric_col], 
                           color=colors[label], 
                           linestyle=styles[label],
                           linewidth=2.0) # Nét vẽ trong zoom nhỏ hơn bên ngoài xíu cho tinh tế
            
            proposed_df = data["Proposed (SelfDistillCore + GN)"]
            
            if metric_col == 'Accuracy':
                axins.set_xlim(zoom_start, last_round)
                axins.set_ylim(90, 100) 
            elif metric_col == 'Loss':
                axins.set_xlim(zoom_start, last_round)
                axins.set_ylim(0, 0.5)

            # Tắt tick X trong ô nhỏ để đỡ rối, nhưng giữ tick Y để người đọc so sánh
            axins.set_xticklabels([]) 
            # Có thể chỉnh font tick riêng cho ô nhỏ nếu cần
            axins.tick_params(axis='y', labelsize=12) 
            
            mark_inset(ax, axins, loc1=2, loc2=4, fc="none", ec="0.4", linewidth=1.5)

    # --- GLOBAL LEGEND ---
    handles, labels = axes[0].get_legend_handles_labels()
    
    # Đẩy Legend xuống sâu hơn (bottom=0.2) để không dính vào chữ trục X
    fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, -0.02), 
               ncol=4, frameon=True, shadow=True, borderpad=1, handlelength=3)

    plt.tight_layout()
    # Tăng khoảng trống bên dưới (bottom) nhiều hơn cho Legend to
    plt.subplots_adjust(bottom=0.22) 
    
    filename = "SelfDistillCore_Ablation_Study_LargeFont.pdf"
    plt.savefig(filename, bbox_inches='tight', format='pdf')
    print(f"Đã lưu biểu đồ tại: {filename}")
    plt.show()

plot_ablation_study_large_font()