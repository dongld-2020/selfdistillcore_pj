import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset

# --- 1. CẤU HÌNH FONT SIZE (Giữ nguyên font to) ---
plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman'],
    'font.size': 20,          
    'axes.labelsize': 20,     
    'axes.labelweight': 'bold', 
    'axes.titlesize': 20,     
    'axes.titleweight': 'bold',
    'xtick.labelsize': 20,    
    'ytick.labelsize': 20,
    'legend.fontsize': 18, # Giảm nhẹ xíu cho vừa khung legend 2 cột
    'figure.dpi': 300,
    'lines.linewidth': 3,   
    'axes.linewidth': 2,    
    'xtick.major.width': 2, 
    'ytick.major.width': 2
})

# --- DATA LOADING ---
files = {
    "Proposed (SelfDistillCore)": "results_selfdistillcore_0.2_0.1_0.9_0.1_groupnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: w/o EWMA": "results_selfdistillcore_0.2_0.0_0.0_0.0_groupnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: No Normalization": "results_selfdistillcore_0.2_0.1_0.9_0.1_nogroupnormnorbatchnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv",
    "Ablation: BatchNorm": "results_selfdistillcore_0.2_0.1_0.9_0.1_batchnorm_clients50_rounds50_epochs3_alpha0.1_lr0.01_seed42_lenet5.csv"
}

data = {}
for label, filename in files.items():
    try:
        df = pd.read_csv(filename)
        data[label] = df
    except FileNotFoundError:
        print(f"Warning: File {filename} not found.")

# --- COLORS ---
colors = {
    "Proposed (SelfDistillCore)": "#D62728",  
    "Ablation: w/o EWMA": "#1F77B4",     
    "Ablation: No Normalization": "#FF7F0E",       
    "Ablation: BatchNorm": "#2CA02C"               
}

styles = {
    "Proposed (SelfDistillCore)": "-",
    "Ablation: w/o EWMA": "--",
    "Ablation: No Normalization": "-.",
    "Ablation: BatchNorm": ":"
}

# --- PLOTTING FUNCTION (CHỈ 2 SUBPLOTS) ---
def plot_ablation_2_subplots():
    # Thay đổi: 1 hàng, 2 cột. Kích thước 16x7
    fig, axes = plt.subplots(1, 2, figsize=(16, 7)) 
    
    # Thay đổi: Chỉ giữ lại Accuracy và Loss
    metrics = [
        ('Accuracy', 'Test Accuracy (%)', 'lower right'),
        ('Loss', 'Test Loss', 'upper right')
    ]

    for idx, (metric_col, metric_name, loc) in enumerate(metrics):
        ax = axes[idx]
        
        for label, df in data.items():
            ax.plot(df['Round'], df[metric_col], 
                    label=label, 
                    color=colors[label], 
                    linestyle=styles[label],
                    alpha=0.9)

        ax.set_xlabel('Communication Rounds')
        ax.set_ylabel(metric_name)
        ax.set_title(f'{metric_name}')
        ax.grid(True, linestyle='--', alpha=0.6, linewidth=1.2)

        # --- INSET ZOOM ---
        last_round = 50
        zoom_start = 30
        
        # Inset box
        axins = inset_axes(ax, width="45%", height="35%", 
                           loc='center right' if metric_col == 'Accuracy' else 'center right')
        
        for label, df in data.items():
            # Bỏ qua BatchNorm nếu nó quá thấp (chỉ áp dụng cho Accuracy)
            if label == "Ablation: BatchNorm" and df[metric_col].iloc[-1] < 50 and metric_col == 'Accuracy':
                continue 
                
            axins.plot(df['Round'], df[metric_col], 
                       color=colors[label], 
                       linestyle=styles[label],
                       linewidth=3.0)
        
        if metric_col == 'Accuracy':
            axins.set_xlim(zoom_start, last_round)
            axins.set_ylim(90, 100) 
        elif metric_col == 'Loss':
            axins.set_xlim(zoom_start, last_round)
            axins.set_ylim(0, 0.5)

        axins.set_xticklabels([]) 
        axins.tick_params(axis='y', labelsize=20) 
        mark_inset(ax, axins, loc1=2, loc2=4, fc="none", ec="0.4", linewidth=1.5)

    # --- GLOBAL LEGEND ---
    handles, labels = axes[0].get_legend_handles_labels()
    
    # Thay đổi: ncol=2 để tạo lưới 2x2, phù hợp với bố cục 2 biểu đồ
    fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, -0.05), 
               ncol=2, frameon=True, shadow=True, borderpad=1, handlelength=3)

    plt.tight_layout()
    # Tăng khoảng trống đáy cho Legend 2 dòng
    plt.subplots_adjust(bottom=0.25) 
    
    filename = "SelfDistillCore_Ablation_Study_2Plots.pdf"
    plt.savefig(filename, bbox_inches='tight', format='pdf')
    print(f"Đã lưu biểu đồ tại: {filename}")
    plt.show()

plot_ablation_2_subplots()