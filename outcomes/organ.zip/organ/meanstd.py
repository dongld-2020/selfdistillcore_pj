import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm  # For color mapping

def load_and_process_data(file_list, metrics_list):
    """
    Tải dữ liệu từ danh sách tệp CSV (mỗi tệp cho một seed).
    Tính toán thống kê cho:
    1. Bảng tóm tắt (Mean/Std trên TẤT CẢ CÁC VÒNG cho các chỉ số hiệu suất,
       giá trị CUỐI CÙNG cho chi phí).
    2. Tất cả các vòng (cho biểu đồ).

    Returns:
        tuple: (table_stats, plot_stats)
        
        table_stats: Dict chứa mean/std.
                     - Cho 'Accuracy', 'Loss', 'F1-Score': Mean/Std trên TẤT CẢ các vòng & seed.
                     - Cho 'Communication_Cost': Mean/Std của giá trị vòng CUỐI CÙNG.
        
        plot_stats: Dict chứa Series (theo vòng) cho mean/std.
                    e.g., {'Accuracy': {'mean': [Series 50 vòng], ...}
    """
    
    # 1. Khởi tạo bộ nhớ
    all_rounds_data = {metric: [] for metric in metrics_list}
    final_round_data = {metric: [] for metric in metrics_list}

    # 2. Đọc và trích xuất dữ liệu từ tệp của mỗi seed
    # (Phần này không thay đổi)
    for file_path in file_list:
        try:
            df = pd.read_csv(file_path)
            for metric in metrics_list:
                if metric in df.columns:
                    # Nối toàn bộ cột (Series) để vẽ biểu đồ
                    all_rounds_data[metric].append(df[metric])
                    # Nối chỉ giá trị cuối cùng (iloc[-1]) cho bảng (chỉ dùng cho Comm. Cost)
                    final_round_data[metric].append(df[metric].iloc[-1])
                else:
                    print(f"WARNING: Column '{metric}' not found in file {file_path}")
        except FileNotFoundError:
            print(f"ERROR: File not found {file_path}. Skipping this file.")
            pass  # Bỏ qua tệp bị thiếu
        except Exception as e:
            print(f"ERROR reading {file_path}: {e}. Skipping this file.")
            pass

    # Kiểm tra xem có dữ liệu nào được tải thành công không
    if not any(all_rounds_data.values()):
        return None, None

    # 3. Tính toán thống kê cho Bảng
    # *** ĐÂY LÀ PHẦN ĐÃ ĐƯỢC CHỈNH SỬA ***
    table_stats = {}
    
    # --- Tính Mean/Std trên TẤT CẢ CÁC VÒNG cho các chỉ số hiệu suất ---
    for metric, series_list in all_rounds_data.items():
        # Bỏ qua Comm_Cost, sẽ được xử lý riêng
        if metric == 'Communication_Cost' or not series_list:
            continue
            
        # Gộp tất cả giá trị từ tất cả các seed và tất cả các vòng thành một Series duy nhất
        all_values_series = pd.concat(series_list, ignore_index=True)
        
        table_stats[metric] = {
            'mean': all_values_series.mean(),
            'std': all_values_series.std()
        }

    # --- Tính Mean/Std cho vòng CUỐI CÙNG chỉ cho Comm. Cost ---
    comm_cost_metric = 'Communication_Cost'
    if comm_cost_metric in final_round_data and final_round_data[comm_cost_metric]:
        values_np = np.array(final_round_data[comm_cost_metric])
        table_stats[comm_cost_metric] = {
            'mean': np.mean(values_np),
            'std': np.std(values_np)
        }

    # 4. Tính toán thống kê cho Biểu đồ (từ all_rounds_data)
    # (Phần này không thay đổi)
    plot_stats = {}
    for metric, series_list in all_rounds_data.items():
        if not series_list:
            continue
            
        # Gộp tất cả series (từ 3 seeds) thành một DataFrame duy nhất
        # Mỗi cột là một seed, mỗi hàng là một vòng
        combined_df = pd.concat(series_list, axis=1)
        
        # Tính mean và std theo hàng (axis=1) để có được thống kê cho từng vòng
        mean_series = combined_df.mean(axis=1)
        std_series = combined_df.std(axis=1)
        
        plot_stats[metric] = {
            'mean': mean_series,
            'std': std_series,
            'upper': mean_series + std_series, # Giới hạn trên (mean + std)
            'lower': mean_series - std_series  # Giới hạn dưới (mean - std)
        }
        
    return table_stats, plot_stats

def print_results_table(all_stats_dict):
    """
    In bảng kết quả đã định dạng, được sắp xếp theo F1-Score (giảm dần)
    và sau đó là Communication Cost (giảm dần).
    
    all_stats_dict: Một từ điển trong đó keys là tên giải thuật và
                    values là 'table_stats' từ load_and_process_data.
    """
    
    # 1. Tạo một danh sách các giải thuật với các khóa sắp xếp
    # (Phần này không thay đổi)
    sortable_algs = []
    for alg_name, stats in all_stats_dict.items():
        # Lấy F1-Score trung bình, mặc định là -1 nếu không tìm thấy
        # (Giờ đây là F1-Score trung bình của tất cả các vòng)
        f1_mean = stats.get('F1-Score', {}).get('mean', -1)
        
        # Lấy Comm. Cost trung bình, mặc định là -1 nếu không tìm thấy
        # (Đây vẫn là chi phí của vòng cuối cùng)
        comm_cost_mean_bytes = stats.get('Communication_Cost', {}).get('mean', -1)
        
        sortable_algs.append((alg_name, f1_mean, comm_cost_mean_bytes, stats))

    # 2. Sắp xếp danh sách:
    # (Phần này không thay đổi)
    sorted_algs = sorted(sortable_algs, key=lambda x: (x[1], x[2]), reverse=True)

    # *** ĐÂY LÀ PHẦN ĐÃ ĐƯỢC CHỈNH SỬA ***
    print("\n" + "="*96)
    print(" 📊 BẢNG SO SÁNH (MEAN ± STD TRÊN TẤT CẢ CÁC VÒNG & SEEDS) ".center(96, "="))
    print(" (Lưu ý: Comm. Cost được tính dựa trên giá trị VÒNG CUỐI CÙNG) ".center(96, " "))
    print("="*96)
    # *** KẾT THÚC PHẦN CHỈNH SỬA ***
    
    print(f"{'Method':<16} | {'Loss':<20} | {'Accuracy (%)':<20} | {'F1-Score':<20} | {'Comm. Cost (MB)':<20}")
    print("-"*99)

    # Hàm trợ giúp để định dạng chuỗi "mean ± std"
    # (Phần này không thay đổi)
    def format_stat(stats_dict, metric_name):
        if metric_name not in stats_dict:
            return f"{'N/A':<20}"
            
        mean = stats_dict[metric_name]['mean']
        std = stats_dict[metric_name]['std']
        
        # Xử lý đặc biệt cho Communication Cost (Bytes -> MB)
        if metric_name == 'Communication_Cost':
            mean /= 1_000_000
            std /= 1_000_000
            
        return f"{mean:<8.4f} \u00B1 {std:<8.4f}"  # \u00B1 là ký tự "±"

    # 3. In bảng đã sắp xếp
    # (Phần này không thay đổi)
    for alg_name, f1, comm_cost, stats in sorted_algs:
        print(f"{alg_name:<16} | "
              f"{format_stat(stats, 'Loss'):<20} | "
              f"{format_stat(stats, 'Accuracy'):<20} | "
              f"{format_stat(stats, 'F1-Score'):<20} | "
              f"{format_stat(stats, 'Communication_Cost'):<20}")
            
    print("="*96 + "\n")

def plot_results_graphs(all_plot_data_dict):
    """
    Vẽ 2 biểu đồ (Accuracy và Loss) với vùng mean ± std
    cho TẤT CẢ các giải thuật.
    """
    # (Hàm này không thay đổi, sao chép từ code của bạn)
    
    # Lấy số lượng giải thuật để tạo màu
    num_algs = len(all_plot_data_dict)
    
    # === SỬA LỖI DEPRECATION WARNING ===
    # Lấy đối tượng colormap 'tab10'
    cmap = plt.get_cmap('tab10')
    # Lấy danh sách 10 màu thực tế từ colormap
    color_list = cmap.colors
    # Tạo bản đồ màu cho mỗi giải thuật, lặp lại danh sách màu
    # bằng toán tử modulo (%).
    color_map = {
        alg_name: color_list[i % len(color_list)] 
        for i, alg_name in enumerate(all_plot_data_dict.keys())
    }
    # =================================

    # Tạo một figure với 2 subplots (xếp chồng lên nhau)
    fig, (ax1, ax2) = plt.subplots(nrows=2, ncols=1, figsize=(16, 12), sharex=True)

    # --- 1. Biểu đồ Accuracy ---
    for alg_name, plot_data in all_plot_data_dict.items():
        if 'Accuracy' not in plot_data: continue
        
        color = color_map[alg_name]
        rounds = plot_data['Accuracy']['mean'].index
        
        # Vẽ đường trung bình - chỉ hiển thị mean trong legend
        ax1.plot(rounds, plot_data['Accuracy']['mean'], 
                 label=f'{alg_name}', color=color, linewidth=3)
        # Vẽ vùng độ lệch chuẩn - không thêm vào legend
        ax1.fill_between(rounds, 
                         plot_data['Accuracy']['lower'], 
                         plot_data['Accuracy']['upper'], 
                         color=color, alpha=0.15)

    ax1.set_title(f'Accuracy Comparison (Mean ± Std On OrganAMNIST with Vgg-11)', fontsize=30)
    ax1.set_ylabel('Accuracy (%)', fontsize=25)
    ax1.grid(True, linestyle='--', alpha=0.6)
    # Đặt legend bên trong plot (phía dưới bên phải)
    ax1.legend(loc='lower right', fontsize=15)
    ax1.tick_params(axis='both', labelsize=25)  # Tăng font size cho số trên cả hai trục    

    # --- 2. Biểu đồ Loss ---
    for alg_name, plot_data in all_plot_data_dict.items():
        if 'Loss' not in plot_data: continue
        
        color = color_map[alg_name]
        rounds = plot_data['Loss']['mean'].index

        ax2.plot(rounds, plot_data['Loss']['mean'], 
                 label=f'{alg_name}', color=color, linewidth=3)
        ax2.fill_between(rounds, 
                         plot_data['Loss']['lower'], 
                         plot_data['Loss']['upper'], 
                         color=color, alpha=0.15)

    ax2.set_title(f'Loss Comparison (Mean ± Std on OrganAMNIST with Vgg-11)', fontsize=30)
    ax2.set_ylabel('Loss', fontsize=25)
    ax2.set_xlabel('Round', fontsize=25)
    ax2.grid(True, linestyle='--', alpha=0.6)
    ax2.legend(loc='upper right', fontsize=15)
    ax2.tick_params(axis='both', labelsize=25)  # Tăng font size cho số trên cả hai trục    

    # --- Hiển thị biểu đồ ---
    plt.tight_layout()
    plt.savefig("loss_accuracy_comparing_on_organA.pdf")
    plt.show()

# --- Thực thi chương trình chính ---

if __name__ == "__main__":
    
    # (Phần này không thay đổi)
    
    # ====================================================================
    # === 📍 VUI LÒNG CẬP NHẬT ĐƯỜNG DẪN TỆP CỦA BẠN TẠI ĐÂY ===
    # ====================================================================
    
    ALGORITHMS_DATA = {
        "SelfDistillCore_K=35%": [
            'results_selfdistillcore_0.35_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_selfdistillcore_0.35_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_selfdistillcore_0.35_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],        
        "SelfDistillCore_K=20%": [
            'results_selfdistillcore_0.2_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_selfdistillcore_0.2_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_selfdistillcore_0.2_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],        
        "SelfDistillCore_K=5%": [
            'results_selfdistillcore_0.05_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_selfdistillcore_0.05_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_selfdistillcore_0.05_0.1_0.9_0.01_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],        
        "FedAvg": [
            'results_fedavg_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_fedavg_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_fedavg_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],
        "FedProx": [
            'results_fedprox_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_fedprox_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_fedprox_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],        
        "Scaffold": [
            'results_scaffold_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_scaffold_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_scaffold_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],
        "FedAdam": [
            'results_fedadam_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_fedadam_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_fedadam_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],
        "FedEma": [
            'results_fedema_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_fedema_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_fedema_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'
        ],
        "FedAvgM": [
            'results_fedavgm_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_fedavgm_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_fedavgm_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'        ],
        "FedZip": [
            'results_fedzip_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed42_vgg11light.csv',
            'results_fedzip_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed84_vgg11light.csv',
            'results_fedzip_clients50_rounds100_epochs3_alpha0.1_lr0.01_seed126_vgg11light.csv'        ]
    }
    # ====================================================================

    # Các chỉ số chúng ta muốn trích xuất
    metrics_to_process = ['Accuracy', 'Loss', 'F1-Score', 'Communication_Cost']
    
    # Nơi lưu trữ tất cả kết quả
    all_table_stats = {}
    all_plot_stats = {}
    
    print("--- Starting data processing ---")
    
    # Lặp qua từng giải thuật, xử lý tệp và lưu trữ kết quả
    for alg_name, file_list in ALGORITHMS_DATA.items():
        # Kiểm tra xem người dùng đã cung cấp đường dẫn tệp thực tế chưa
        if not file_list or not any(file_list) or "..." in file_list[0]:
            print(f"Skipping {alg_name}: No data files provided or still using placeholders.")
            continue
            
        print(f"Processing data for {alg_name}...")
        table_stats, plot_stats = load_and_process_data(file_list, metrics_to_process)
        
        if table_stats and plot_stats:
            all_table_stats[alg_name] = table_stats
            all_plot_stats[alg_name] = plot_stats
        else:
            print(f"Error or no data found for {alg_name}.")
            
    print("--- Processing complete ---")
    
    # 2. In bảng kết quả
    if all_table_stats:
        print_results_table(all_table_stats)
    else:
        print("No data was successfully processed to print the table.")
    
    # 3. Vẽ biểu đồ
    if all_plot_stats:
        print("Generating plots... (A new window will appear)")
        plot_results_graphs(all_plot_stats)
        print("Plots displayed. Close the plot window to exit the program.")
    else:
        print("Could not generate plots due to data processing errors.")